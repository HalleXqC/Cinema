import cls from './Swiper.module.scss'

const Swiper = () => {
    return (
        <div className={cls.root}>
            <h1>Swiper</h1>
        </div>
    )
}

export default Swiper