export const getMoviesRoute = 'movies'
export const getSnacksRoute = 'snacks'